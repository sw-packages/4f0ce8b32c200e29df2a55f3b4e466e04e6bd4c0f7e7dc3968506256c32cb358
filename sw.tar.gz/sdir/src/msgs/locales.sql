INSERT INTO LOCALES (LOCALE, DESCRIPTION) VALUES ('pg_PG', 'Pig Latin, testing locale only.');
INSERT INTO LOCALES (LOCALE, DESCRIPTION) VALUES ('fr_FR', 'French as used in France, Latin 1 codeset');
INSERT INTO LOCALES (LOCALE, DESCRIPTION) VALUES ('de_DE', 'German as used in Germany, Latin 1 codeset');
INSERT INTO LOCALES (LOCALE, DESCRIPTION) VALUES ('ja_JP.EUC', 'Japanese EUC codeset');
INSERT INTO LOCALES (LOCALE, DESCRIPTION) VALUES ('piglatin', 'Testing locale only');
INSERT INTO LOCALES (LOCALE, DESCRIPTION) VALUES ('ko_KO', 'korean locale using UNICODE');

COMMIT WORK;
